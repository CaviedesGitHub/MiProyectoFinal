#from candidato import create_app
#from candidato.vistas.vistas import VistaPing, VistaBorrar, VistaCandidatosPerfiles, VistaCandidato
#from candidato.modelos.modelos import db, Candidato, Estado
from flask_restful import Api
from flask_jwt_extended import JWTManager
from faker import Faker
import random
import os

from flask import Flask
#def create_app(config_name, settings_module='candidato.config.ProductionConfig'):
#    app=Flask(__name__)
#    app.config.from_object(settings_module)
#    return app

def create_app(config_name):
    app=Flask(__name__)
    app.config['SECRET_KEY'] = '7110c8ae51a4b5af97be6534caef90e4bb9bdcb3380af008f90b23a5d1616bf319bc298105da20fe'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = 'Proyecto2023'
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = False

    if 'RDS_HOSTNAME' in os.environ:
        NAME=os.environ['RDS_DB_NAME']
        USER=os.environ['RDS_USERNAME']
        PASSWORD=os.environ['RDS_PASSWORD']
        HOST=os.environ['RDS_HOSTNAME']
        PORT=os.environ['RDS_PORT']
        app.config['SQLALCHEMY_DATABASE_URI']=f'postgresql://{USER}:{PASSWORD}@{HOST}:{PORT}/{NAME}'
    else:
        app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://admin:admin@localhost:5432/CandidatosBD'      
    return app                                   

#settings_module = os.getenv('APP_SETTINGS_MODULE','candidato.config.ProductionConfig')
#application = create_app('default', settings_module)
application = create_app('default')
app_context=application.app_context()
app_context.push()



import enum
from flask_sqlalchemy import SQLAlchemy
from marshmallow_sqlalchemy import SQLAlchemyAutoSchema
from marshmallow import fields
from sqlalchemy import DateTime, Date
from sqlalchemy.sql import func

try:

    db = SQLAlchemy()


    db.init_app(application)
    db.create_all()
except Exception as inst:
    print(type(inst))    # the exception instance
    #print(inst)
    print("No se pudo obtener la informacion del candidato.")



from datetime import datetime
from datetime import timedelta
import math
import random
import uuid
from flask import request
from flask_restful import Resource
from sqlalchemy.exc import IntegrityError
#from candidato.modelos.modelos import db, Candidato, CandidatoSchema, Estado
from sqlalchemy import desc, asc

import os
#import requests
import json
from faker import Faker


class VistaRaiz(Resource):
    def get(self):
        print("Hola")
        return {"Mensaje":"Hola, Bienvenido De Nuevo v3.3 Inmutable"}, 200

class VistaPing(Resource):
    def get(self):
        print("pong")
        return {"Mensaje":"Pong version 3.3 Inmutable"}, 200

class VistaEnv(Resource):
    def get(self):
        print("Environment")
        return {
            "RDS_DB_NAME":os.environ['RDS_DB_NAME'],
            "RDS_USERNAME":os.environ['RDS_USERNAME'],
            "RDS_PASSWORD":os.environ['RDS_PASSWORD'],
            "RDS_HOSTNAME":os.environ['RDS_HOSTNAME'],
            "RDS_PORT":os.environ['RDS_PORT'],
            "URL_DATABASE":application.config['SQLALCHEMY_DATABASE_URI'],
        }, 200

api = Api(application)
api.add_resource(VistaRaiz, '/')
api.add_resource(VistaPing, '/ping')
api.add_resource(VistaEnv, '/env')


#api = Api(application)
#api.add_resource(VistaBorrar, '/candidatos/borrar')
#api.add_resource(VistaCandidatosPerfiles, '/candidatos/perfiles')
#api.add_resource(VistaCandidato, '/candidato/<int:id_cand>')
#api.add_resource(VistaPing, '/candidato/ping')


jwt = JWTManager(application)

"""if Candidato.get_count()==0:
    faker=Faker(['es_CO'])
    registros=0
    for i in range(500):
        try:
            cn=Candidato()
            cn.nombres=faker.first_name()
            cn.apellidos=faker.last_name()
            cn.documento=faker.unique.random_int(min=1000000, max=2000000000) 
            cn.direccion=faker.street_address()
            cn.ciudad=faker.city()
            cn.email=faker.email()
            cn.phone=faker.phone_number()
            cn.fecha_nac=faker.date_between(start_date= "-80y" ,end_date= "-18y" )
            cn.estado=Estado.ACTIVO
            cn.num_perfil=(registros+1) % 250  #random.randint(1, 300)
            db.session.add(cn)
            db.session.commit()
            registros=registros+1
        except Exception as inst:
            db.session.rollback()
            print(type(inst))    # the exception instance
            #print(inst)
            print("registro no se pudo guardar.")
    
    faker=Faker(['en_US'])
    for i in range(300):
        try:
            cn=Candidato()
            cn.nombres=faker.first_name()
            cn.apellidos=faker.last_name()
            cn.documento=faker.unique.random_int(min=1000000, max=2000000000) 
            cn.direccion=faker.street_address()
            cn.ciudad=faker.city()
            cn.email=faker.email()
            cn.phone=faker.phone_number()
            cn.fecha_nac=faker.date_between(start_date= "-80y" ,end_date= "-18y" )
            cn.estado=Estado.ACTIVO
            cn.num_perfil=(registros+1) % 250  #random.randint(1, 300)
            db.session.add(cn)
            db.session.commit()
            registros=registros+1
        except Exception as inst:
            db.session.rollback()
            print(type(inst))    # the exception instance
            #print(inst)
            print("registro no se pudo guardar.")
    
    faker=Faker(['it_IT'])
    for i in range(200):
        try:
            cn=Candidato()
            cn.nombres=faker.first_name()
            cn.apellidos=faker.last_name()
            cn.documento=faker.unique.random_int(min=1000000, max=2000000000) 
            cn.direccion=faker.street_address()
            cn.ciudad=faker.city()
            cn.email=faker.email()
            cn.phone=faker.phone_number()
            cn.fecha_nac=faker.date_between(start_date= "-80y" ,end_date= "-18y" )
            cn.estado=Estado.ACTIVO
            cn.num_perfil=(registros+1) % 250  #random.randint(1, 300)
            db.session.add(cn)
            db.session.commit()
            registros=registros+1
        except Exception as inst:
            db.session.rollback()
            print(type(inst))    # the exception instance
            #print(inst)
            print("registro no se pudo guardar.")"""

#if __name__ == "__main__":
#    application.run(port = 5000, debug = True)