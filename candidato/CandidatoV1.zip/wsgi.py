from candidato.application import application
if __name__ == "__main__":
    app.run()